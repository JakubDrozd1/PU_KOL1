﻿namespace BLL.DTO
{
    public class StudentDto
    {
        public int ID { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int? IDGrupy { get; set; }
    }
}
