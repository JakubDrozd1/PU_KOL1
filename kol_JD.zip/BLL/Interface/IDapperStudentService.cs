﻿using BLL.DTO;

namespace BLL.Interface
{
    public interface IDapperStudentService
    {
        Task<StudentDto> CreateAsync(StudentDto dto);

    }
}
