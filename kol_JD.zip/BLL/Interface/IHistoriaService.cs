﻿using BLL.DTO;

namespace BLL.Interface
{
    public interface IHistoriaService
    {
        Task<List<HistoriaDto>> GetPagedAsync(int pageNumber, int pageSize);
    }
}
