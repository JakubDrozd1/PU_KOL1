﻿using BLL.DTO;
using BLL.Interface;
using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_EF
{
    public class DapperHistoriaService: IDapperHistoriaService
    {
        private readonly string _connectionString;

        public DapperHistoriaService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<List<HistoriaDto>> GetPagedAsync(int pageNumber, int pageSize)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@PageNumber", pageNumber);
            parameters.Add("@PageSize", pageSize);

            var result = await connection.QueryAsync<HistoriaDto>(
                "GetHistoriaPaged",
                parameters,
                commandType: CommandType.StoredProcedure);

            return result.ToList();
        }
    }
}
