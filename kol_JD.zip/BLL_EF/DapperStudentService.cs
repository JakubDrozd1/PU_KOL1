﻿using BLL.DTO;
using BLL.Interface;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_EF
{
    public class DapperStudentService : IDapperStudentService
    {
        private readonly string _connectionString;

        public DapperStudentService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<StudentDto> CreateAsync(StudentDto dto)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();

            parameters.Add("@Imie", dto.Imie);
            parameters.Add("@Nazwisko", dto.Nazwisko);
            parameters.Add("@IDGrupy", dto.IDGrupy, DbType.Int32);
            parameters.Add("@NewStudentID", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("AddStudent", parameters, commandType: CommandType.StoredProcedure);

            dto.ID = parameters.Get<int>("@NewStudentID");
            return dto;
        }
    }
}
