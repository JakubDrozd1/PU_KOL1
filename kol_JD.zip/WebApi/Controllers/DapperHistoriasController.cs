﻿using BLL.DTO;
using BLL.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DapperHistoriasController : ControllerBase
    {
        private readonly IDapperHistoriaService _historiaService;
        public DapperHistoriasController(IDapperHistoriaService historiaService)
        {
            _historiaService = historiaService;
        }
        [HttpGet("paged")]
        public async Task<ActionResult<List<HistoriaDto>>> GetPaged([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            if (pageNumber < 1 || pageSize < 1)
                return BadRequest("pageNumber i pageSize muszą być większe od zera.");

            var result = await _historiaService.GetPagedAsync(pageNumber, pageSize);
            return Ok(result);
        }
    }
}
