﻿
namespace kol
{
    public class Grupa
    {
        public int ID { get; set; }
        public string Nazwa { get; set; }
        public ICollection<Student> Studenci { get; set; } = new List<Student>();
    }
}
