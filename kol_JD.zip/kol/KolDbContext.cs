﻿using Microsoft.EntityFrameworkCore;

namespace kol
{
    public class KolDbContext : DbContext
    {
        public DbSet<Student> Studenci { get; set; }
        public DbSet<Grupa> Grupy { get; set; }
        public DbSet<Historia> Historie { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DbUczelnia;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False"); 
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>()
                .HasOne(s => s.Grupa)
                .WithMany(g => g.Studenci)
                .HasForeignKey(s => s.IDGrupy)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<Historia>()
                .Property(h => h.TypAkcji)
                .IsRequired();
        }
    }
}
