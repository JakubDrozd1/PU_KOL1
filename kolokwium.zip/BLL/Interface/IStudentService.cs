﻿using BLL.DTO;

namespace BLL.Interface
{
    public interface IStudentService
    {
        Task<List<StudentDto>> GetAllAsync();
        Task<StudentDto?> GetByIdAsync(int id);
        Task<StudentDto> CreateAsync(StudentDto student);
        Task<StudentDto?> UpdateAsync(int id, StudentDto student);
        Task<bool> DeleteAsync(int id);
    }
}
