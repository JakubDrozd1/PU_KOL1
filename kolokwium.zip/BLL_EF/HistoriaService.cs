﻿using BLL.DTO;
using BLL.Interface;
using kol;
using Microsoft.EntityFrameworkCore;

namespace BLL_EF
{
    public class HistoriaService: IHistoriaService
    {
        private readonly KolDbContext _context;

        public HistoriaService(KolDbContext context)
        {
            _context = context;
        }

        public async Task<List<HistoriaDto>> GetPagedAsync(int pageNumber, int pageSize)
        {
            return await _context.Historie
                .OrderByDescending(h => h.Data)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Select(h => new HistoriaDto
                {
                    ID = h.ID,
                    Imie = h.Imie,
                    Nazwisko = h.Nazwisko,
                    IDGrupy = h.IDGrupy,
                    TypAkcji = h.TypAkcji,
                    Data = h.Data
                }).ToListAsync();
        }
    }
}
