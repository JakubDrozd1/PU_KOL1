﻿using BLL.DTO;
using BLL.Interface;
using kol;
using Microsoft.EntityFrameworkCore;


namespace BLL_EF
{
    public class StudentService : IStudentService
    {
        private readonly KolDbContext _context;

        public StudentService(KolDbContext context)
        {
            _context = context;
        }

        public async Task<List<StudentDto>> GetAllAsync()
        {
            return await _context.Studenci
                .Select(s => new StudentDto
                {
                    ID = s.ID,
                    Imie = s.Imie,
                    Nazwisko = s.Nazwisko,
                    IDGrupy = s.IDGrupy
                }).ToListAsync();
        }

        public async Task<StudentDto?> GetByIdAsync(int id)
        {
            var student = await _context.Studenci.FindAsync(id);
            if (student == null) return null;

            return new StudentDto
            {
                ID = student.ID,
                Imie = student.Imie,
                Nazwisko = student.Nazwisko,
                IDGrupy = student.IDGrupy
            };
        }

        public async Task<StudentDto> CreateAsync(StudentDto dto)
        {
            var student = new Student
            {
                Imie = dto.Imie,
                Nazwisko = dto.Nazwisko,
                IDGrupy = dto.IDGrupy
            };

            _context.Studenci.Add(student);
            await _context.SaveChangesAsync();

            dto.ID = student.ID;
            return dto;
        }

        public async Task<StudentDto?> UpdateAsync(int id, StudentDto dto)
        {
            var student = await _context.Studenci.FindAsync(id);
            if (student == null) return null;

            student.Imie = dto.Imie;
            student.Nazwisko = dto.Nazwisko;
            student.IDGrupy = dto.IDGrupy;

            await _context.SaveChangesAsync();
            return dto;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var student = await _context.Studenci.FindAsync(id);
            if (student == null) return false;

            _context.Studenci.Remove(student);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
