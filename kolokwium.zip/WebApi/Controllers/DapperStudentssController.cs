﻿using BLL.DTO;
using BLL.Interface;
using BLL_EF;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DapperStudentssController : ControllerBase
    {
        private readonly IDapperStudentService _studentService;
        public DapperStudentssController(IDapperStudentService studentService)
        {
            _studentService = studentService;
        }
        [HttpPost]
        public async Task<ActionResult<StudentDto>> Create(StudentDto dto)
        {
            var created = await _studentService.CreateAsync(dto);
            return Ok();
        }
    }
}
